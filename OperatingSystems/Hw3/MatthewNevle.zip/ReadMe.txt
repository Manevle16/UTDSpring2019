Compile the java files by typing "make" in the project directory
Run in project directory using "java -cp ./bin Main a b k n" where 
a is the start of the range, b is the end of the range, k is the amount 
of top numbers to be found, and n is the number of threads to use